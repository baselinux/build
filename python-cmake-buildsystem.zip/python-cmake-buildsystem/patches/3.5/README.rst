* ``0001-Prevent-incorrect-include-of-io.h-and-memory.h-found.patch``: Rename header files found in
  ``Modules/_decimal/libmpdec`` directory to avoid conflicts with system headers of the same name.

* ``0002-Prevent-duplicated-OverlappedType-symbols-with-built.patch``: Prevent duplicated OverlappedType
  symbols with built-in extension on Windows.

* ``0003-mpdecimal-Export-inlined-functions-to-support-extens.patch``: Export inlined functions to
  support extension built-in on Windows.


