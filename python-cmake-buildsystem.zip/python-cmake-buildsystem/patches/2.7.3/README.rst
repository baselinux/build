* ``0001-Backport-Issue-20374-Fix-build-with-GNU-readline-6.3.patch``: Issue #20374: Fix build with GNU
  readline >= 6.3. See `python/cpython@ce75105 <https://github.com/python/cpython/commit/ce75105>`_.

* ``0002-Backport-new-plan-just-remove-typecasts-closes-20374.patch``: new plan: just remove typecasts (closes #20374).
  See `python/cpython@0ac0ead <https://github.com/python/cpython/commit/0ac0ead>`_.

* ``0003-Backport-Issue-20374-Avoid-compiler-warnings-when-co.patch``: Issue #20374: Avoid compiler warnings when
  compiling readline with libedit. See `python/cpython@b0fd12d <https://github.com/python/cpython/commit/b0fd12d>`_.

